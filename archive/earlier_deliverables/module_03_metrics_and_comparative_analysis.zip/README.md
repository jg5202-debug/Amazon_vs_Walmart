# Retail Growth and Profitability Comparison

这个文件夹归集了当前零售比较项目的 Notebook、研究配置、实际数据与数据库、四模块规划、流程图、中文逐句 guide、原交付包及修正备份。最新总 Notebook 与数据从你的 Desktop/JupyterProject 复制而来；原文件继续保留。

## 从这里开始

打开根目录 retail_growth_and_profitability_comparison.ipynb，将 kernel 工作目录设为本文件夹，按 Module 01、Module 02 的顺序运行。Notebook 已包含前三个模块全部代码，共 32 个 code cells。原来保存的输出可能显示旧 Desktop 路径；重新运行后会显示本项目的实际路径。

代码详解见 module_02/module_02_code_explanation_guide.html，用浏览器打开；Markdown 版本在同目录。研究进展和代码风格要求见 PROJECT_CONTEXT.md。Module 03 已完成指标与阶段汇总；Module 04 图表与报告尚未生成。

## 文件位置

根目录总 Notebook 和 study.json 是当前入口。data/raw/ 为原始转录输入，data/financial_data.csv 为组合快照，data/clean/financial_records.csv 为标准化核对表，data/retail_comparison.sqlite 为最新数据库快照。

module_01/、module_02/ 与 module_03/ 保留配套代码、独立 Notebook、说明和来源。diagrams/ 保留英文流程图 PNG 和 SVG。project_plan.md 与 diagram_guide.md 保存规划和流程说明。single_notebook_fix/ 包含路径修正说明及修改前备份。根目录 zip 包是以前的交付版本快照，可用于参考。

## 加入 Codex 的项目栏

此文件夹准备完成，但尚未通过工具注册为侧边栏项目。在“项目”中添加本地项目并选择本文件夹，项目名称可用 Retail Growth and Profitability Comparison。

新项目聊天继续工作时，请先读取 PROJECT_CONTEXT.md 与最新总 Notebook。完整旧聊天不会因为复制文件自动迁移；若应用聊天菜单提供移至项目功能，可将“推荐零售业新旧公司对比”移入该项目。不要以本上下文摘要代替完整历史的自动迁移。

官方说明：https://learn.chatgpt.com/docs/projects?surface=app

## 验证与来源

准备阶段确认最新桌面数据库为两条分部资料、十二条财务记录、零条指标结果，integrity_check 为 ok。SQLite backup 用于取得一致快照。sources_manifest 和 source_notes 保留免费官方来源及采用版本，不声称包含完整官方报告 HTML。

## Module 03 新增交付

module_03/module_03_code_explanation_guide.html 为第三模块代码与中文逐句解释分开排版的阅读版，guide.md 为 Markdown 版。results/ 保存年度指标、长结果、阶段汇总与分析清单。当前数据库有 36 条指标，其中两条首年同比为 NULL；重复相同输入不增行。验证包含独立公式、基期和指标配置变化、回读、事务及旧输入检查。
